
import React, { useState, useEffect, useRef } from 'react';
import { TopicData } from '../types';
import { callGemini, generateSpeech } from '../services/geminiService';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  topicId: string;
  topic: TopicData;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, topicId, topic }) => {
  const [aiOutput, setAiOutput] = useState<string>("AI insights will appear here...");
  const [query, setQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const audioRef = useRef<{ context: AudioContext, source: AudioBufferSourceNode } | null>(null);

  if (!isOpen) return null;

  const handlePredictQuestions = async () => {
    setIsLoading(true);
    setAiOutput("✨ Professor Gemini is predicting questions...");
    const result = await callGemini(
      `Topic: ${topic.title}. Notes: ${topic.details}. Predict 3 specific exam questions (1 short, 1 long).`,
      "You are a Distributed Systems professor."
    );
    setAiOutput(result);
    setIsLoading(false);
  };

  const handleAskAI = async () => {
    if (!query.trim()) return;
    setIsLoading(true);
    setAiOutput("✨ Thinking...");
    const result = await callGemini(`Query: ${query}. Context: ${topic.details}`, "Explain in simple student terms.");
    setAiOutput(result);
    setQuery("");
    setIsLoading(false);
  };

  const handleTTS = async () => {
    if (isSpeaking) {
      if (audioRef.current) {
        audioRef.current.source.stop();
        setIsSpeaking(false);
      }
      return;
    }

    setIsSpeaking(true);
    const cleanSummary = topic.summary.replace(/<[^>]*>/g, '');
    const speech = await generateSpeech(cleanSummary);
    
    if (speech) {
      const { audioBuffer, audioContext } = speech;
      const source = audioContext.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioContext.destination);
      source.start();
      source.onended = () => setIsSpeaking(false);
      audioRef.current = { context: audioContext, source };
    } else {
      setAiOutput("AI Audio service is temporarily unavailable.");
      setIsSpeaking(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-bg-dark/95 backdrop-blur-[25px] z-[2000] flex items-center justify-center p-4">
      <div className="bg-surface max-w-[1000px] w-full max-h-[92vh] border border-neon-blue rounded-3xl p-6 lg:p-12 relative shadow-[0_0_60px_rgba(0,242,255,0.3)] overflow-y-auto custom-scrollbar">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 text-neon-blue text-3xl hover:scale-110 transition-transform cursor-pointer z-[2001]"
        >
          <i className="fa-solid fa-xmark"></i>
        </button>

        <div className="space-y-8">
          <h3 className="font-orbitron text-neon-blue text-2xl lg:text-3xl uppercase tracking-tighter border-b border-white/10 pb-4">
            {topic.title}
          </h3>

          <div className="bg-neon-blue/5 border border-neon-blue p-6 rounded-2xl relative">
            <button 
              onClick={handleTTS}
              className={`absolute top-4 right-4 w-10 h-10 rounded-full flex items-center justify-center border border-neon-blue text-neon-blue transition-all ${isSpeaking ? 'bg-neon-blue text-slate-900 animate-pulse' : 'bg-neon-blue/20 hover:bg-neon-blue hover:text-slate-900'}`}
            >
              {isSpeaking ? <i className="fa-solid fa-stop"></i> : <i className="fa-solid fa-volume-high"></i>}
            </button>
            <h4 className="text-neon-blue font-orbitron text-xs uppercase tracking-widest mb-3">Quick Concept (Hinglish)</h4>
            <p className="text-white italic text-lg leading-relaxed pr-10" dangerouslySetInnerHTML={{ __html: topic.summary }}></p>
          </div>

          {topic.diagram && (
            <div className="bg-black rounded-2xl p-8 border border-white/5 flex flex-col items-center justify-center">
              <div dangerouslySetInnerHTML={{ __html: topic.diagram }} />
              <div className="mt-4 text-[10px] text-slate-500 font-mono uppercase tracking-[2px]">Architecture Overview</div>
            </div>
          )}

          <div className="space-y-4">
            <h4 className="text-neon-purple font-orbitron text-sm uppercase border-l-4 border-neon-purple pl-4">Detailed Technical Exam Notes</h4>
            <div className="text-slate-400 leading-relaxed text-sm" dangerouslySetInnerHTML={{ __html: topic.details }} />
          </div>

          <div className="mt-12 p-8 bg-gradient-to-br from-neon-purple/10 to-neon-blue/5 border border-neon-purple/40 rounded-3xl space-y-6">
            <div className="flex items-center gap-3 text-neon-purple font-orbitron text-sm">
              <i className="fa-solid fa-wand-magic-sparkles"></i> Gemini AI Assistant
            </div>
            
            <div className="flex gap-3 flex-wrap">
              <button 
                onClick={handlePredictQuestions}
                disabled={isLoading}
                className="bg-neon-purple/20 border border-neon-purple text-white px-5 py-2.5 rounded-full font-orbitron text-[10px] hover:bg-neon-purple hover:text-slate-900 transition-all disabled:opacity-50"
              >
                {isLoading ? <span className="animate-spin inline-block mr-2"><i className="fa-solid fa-circle-notch"></i></span> : '✨'} Predict Exam Questions
              </button>
            </div>

            <div className="bg-black/40 p-5 rounded-xl border border-white/5 text-slate-300 text-sm min-h-[80px] leading-relaxed whitespace-pre-wrap">
              {aiOutput}
            </div>

            <div className="flex gap-3">
              <input 
                type="text" 
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAskAI()}
                className="flex-grow bg-white/5 border border-white/10 rounded-xl p-3 px-4 text-white outline-none focus:border-neon-blue transition-colors text-sm"
                placeholder={`Ask AI about ${topic.title}...`}
              />
              <button 
                onClick={handleAskAI}
                className="bg-neon-blue/20 border border-neon-blue text-neon-blue p-3 px-6 rounded-xl hover:bg-neon-blue hover:text-slate-900 transition-all"
              >
                <i className="fa-solid fa-paper-plane"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Modal;
