
import React from 'react';
import { NavItem } from '../types';
import { NAV_ITEMS } from '../constants';

interface SidebarProps {
  activeNavIdx: number;
  onJump: (idx: number) => void;
  isOpen: boolean;
  onToggle: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeNavIdx, onJump, isOpen, onToggle }) => {
  return (
    <aside className={`
      fixed inset-y-0 left-0 z-[1000] w-[280px] glass p-8 flex flex-col gap-2 transition-all duration-300
      lg:static lg:translate-x-0 ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      rounded-r-2xl lg:rounded-2xl
    `}>
      <div className="flex items-center gap-3 pb-8 mb-4 border-b border-white/10">
        <div className="w-10 h-10 flex items-center justify-center">
          <img 
            src="https://drive.google.com/thumbnail?id=1uY7-npxkT8NStw2u79Eyj8Kbhcpxmimb&sz=500" 
            className="max-w-full max-h-full object-contain drop-shadow-[0_0_5px_#00f2ff]" 
            alt="Logo" 
          />
        </div>
        <div>
          <h2 className="font-orbitron text-sm text-white font-bold leading-tight">
            DISTRIBUTED<br/><span className="text-neon-blue">SYSTEM.</span>
          </h2>
        </div>
      </div>
      
      <nav className="flex flex-col gap-2">
        {NAV_ITEMS.map((item) => (
          <div
            key={item.id}
            onClick={() => onJump(item.slideIdx)}
            className={`
              p-3 px-4 rounded-xl cursor-pointer transition-all flex items-center gap-3 font-orbitron text-[11px] uppercase tracking-wider
              border border-transparent hover:bg-white/5 hover:text-white
              ${activeNavIdx === item.id ? 'bg-gradient-to-r from-neon-blue/10 to-transparent border-l-4 border-l-neon-blue text-neon-blue' : 'text-slate-400'}
            `}
          >
            <i className={`fa-solid ${item.icon}`}></i> {item.label}
          </div>
        ))}
      </nav>

      <div className="mt-auto pt-6 border-t border-white/10 flex flex-col gap-4">
        <a href="https://www.instagram.com/careercue.co/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 text-slate-400 hover:text-neon-blue transition-colors font-mono text-[11px]">
          <i className="fa-brands fa-instagram"></i> careercue.co
        </a>
        <a href="https://www.instagram.com/master_rahul.ind/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 text-slate-400 hover:text-neon-blue transition-colors font-mono text-[11px]">
          <i className="fa-brands fa-instagram"></i> master_rahul.ind
        </a>
      </div>
    </aside>
  );
};

export default Sidebar;
